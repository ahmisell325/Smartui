import fs from 'fs';
import archiver from 'archiver';

// Create a file to stream archive data to
const output = fs.createWriteStream('pagemart-landing-page.zip');
const archive = archiver('zip', {
  zlib: { level: 9 } // Sets the compression level
});

// Listen for all archive data to be written
output.on('close', function() {
  console.log('Archive created successfully!');
  console.log('Total bytes: ' + archive.pointer());
  console.log('Download the file from the Files tab on the left.');
});

// Handle warnings and errors
archive.on('warning', function(err) {
  if (err.code === 'ENOENT') {
    console.warn(err);
  } else {
    throw err;
  }
});

archive.on('error', function(err) {
  throw err;
});

// Pipe archive data to the file
archive.pipe(output);

// Add all files and directories (except node_modules and other large folders)
archive.glob('**/*', {
  ignore: [
    'node_modules/**',
    '.git/**',
    '*.zip',
    '.replit',
    '.upm/**',
    '.cache/**'
  ]
});

// Finalize the archive
archive.finalize();