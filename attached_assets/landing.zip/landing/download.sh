#!/bin/bash

# Create the zip file directly, excluding unnecessary directories
zip -r pagemart-landing-page.zip ./* \
    -x "node_modules/*" \
    -x ".git/*" \
    -x ".replit" \
    -x ".upm/*" \
    -x ".cache/*" \
    -x "*.zip" \
    -x "download.*"

echo "Archive created successfully at: pagemart-landing-page.zip"
echo "You can download it from the Files tab on the left."