import { useEffect } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import Pricing from "@/components/Pricing";
import Testimonials from "@/components/Testimonials";
import Newsletter from "@/components/Newsletter";
import CTA from "@/components/CTA";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";
import CookieBanner from "@/components/CookieBanner";
import BackToTop from "@/components/BackToTop";
import PlanModal from "@/components/PlanModal";
import TrustedCompanies from "@/components/TrustedCompanies";
import { useScroll } from "@/hooks/use-scroll";

export default function Home() {
  const { scrollPosition, scrollProgress } = useScroll();

  // Set page title and metadata
  useEffect(() => {
    document.title = "PageMart - Premium Landing Page Templates";
  }, []);

  return (
    <>
      {/* Skip to content link for accessibility */}
      <a href="#main-content" className="skip-to-content">
        Skip to content
      </a>
      
      {/* Scroll Progress Indicator */}
      <div className="progress-bar" style={{ width: `${scrollProgress}%` }}></div>
      
      <Header />
      
      <main id="main-content" className="flex-grow">
        <Hero />
        <TrustedCompanies />
        <Features />
        <Pricing />
        <Testimonials />
        <Newsletter />
        <CTA />
        <FAQ />
      </main>
      
      <Footer />
      <CookieBanner />
      <BackToTop visible={scrollPosition > 500} />
      <PlanModal />
    </>
  );
}
