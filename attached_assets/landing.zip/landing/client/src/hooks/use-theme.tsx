import { useEffect } from "react";
import { useTheme as useNextTheme } from "next-themes";

export function useTheme() {
  const { theme, setTheme, systemTheme } = useNextTheme();

  useEffect(() => {
    // Check for saved theme preference
    const savedTheme = localStorage.getItem("theme");
    
    if (savedTheme) {
      setTheme(savedTheme);
    } else if (systemTheme) {
      // If no saved preference, use system preference
      setTheme(systemTheme);
    }
  }, [setTheme, systemTheme]);

  return {
    theme,
    setTheme,
    systemTheme,
  };
}
