import { Smartphone, PaintBucket, Search, Headphones, ChevronRight } from "lucide-react";

const features = [
  {
    icon: <Smartphone className="h-6 w-6" />,
    title: "Fully Responsive",
    description: "Optimized for all devices with a 99.8% rendering accuracy across 50+ browser and device combinations.",
  },
  {
    icon: <PaintBucket className="h-6 w-6" />,
    title: "Easy Customization",
    description: "Modify designs in 50% less time with our intuitive drag-and-drop editor and 200+ pre-built components.",
  },
  {
    icon: <Search className="h-6 w-6" />,
    title: "SEO Optimized",
    description: "Built with SEO best practices that improve page rank by up to 35% and reduce load times by 2.5x.",
  },
  {
    icon: <Headphones className="h-6 w-6" />,
    title: "24/7 Support",
    description: "Access expert assistance with average response time of 2.5 hours and 98% customer satisfaction rating.",
  },
];

export default function Features() {
  return (
    <section id="templates" className="py-16 md:py-24 bg-background transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Key Features</h2>
          <p className="max-w-2xl mx-auto text-muted-foreground">
            Our templates are designed with conversion in mind, helping you create stunning landing pages that drive results.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="feature-card">
              <div className="relative z-10">
                <div className="feature-icon">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
                <div className="mt-4 flex items-center text-primary font-medium group">
                  <span>Learn more</span>
                  <ChevronRight className="h-4 w-4 ml-2 transition-transform duration-300 group-hover:translate-x-1" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
