import { useState, useEffect } from "react";
import { Sun, Moon, Menu, X } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeLink, setActiveLink] = useState("hero");
  const { theme, setTheme } = useTheme();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    // Prevent scrolling when menu is open
    document.body.style.overflow = isMenuOpen ? "" : "hidden";
  };

  // Track scroll position to highlight active navigation link
  useEffect(() => {
    const handleScroll = () => {
      const sections = ["hero", "templates", "pricing", "testimonials", "faq"];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;

          if (
            scrollPosition >= offsetTop &&
            scrollPosition < offsetTop + offsetHeight
          ) {
            setActiveLink(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className="fixed w-full bg-background shadow-md z-50 transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <nav className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4">
            {/* Responsive Logo */}
            <a href="#" className="flex items-center">
              <span className="text-2xl font-bold text-primary">PageMart</span>
              <span className="hidden md:inline-block text-xs ml-2 bg-secondary/10 dark:bg-secondary/20 text-secondary dark:text-secondary/80 px-2 py-1 rounded">
                v2.0
              </span>
            </a>
          </div>

          <div className="hidden md:flex items-center space-x-1">
            <ul className="flex space-x-1">
              <li>
                <a
                  href="#templates"
                  className={`nav-link ${activeLink === "templates" ? "active" : ""}`}
                >
                  Templates
                </a>
              </li>
              <li>
                <a
                  href="#pricing"
                  className={`nav-link ${activeLink === "pricing" ? "active" : ""}`}
                >
                  Pricing
                </a>
              </li>
              <li>
                <a
                  href="#faq"
                  className={`nav-link ${activeLink === "faq" ? "active" : ""}`}
                >
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div className="flex items-center space-x-4">
            {/* Theme Toggle with Better Accessibility */}
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-muted transition-colors duration-200"
              aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
              aria-pressed={theme === "dark"}
            >
              {theme === "dark" ? (
                <Moon className="h-5 w-5 text-secondary" />
              ) : (
                <Sun className="h-5 w-5 text-yellow-500" />
              )}
              <span className="sr-only">Toggle dark mode</span>
            </button>

            <div className="hidden md:flex items-center space-x-2">
              <a
                href="#"
                className="px-4 py-2 text-sm font-medium border-2 border-primary text-primary hover:bg-primary/10 rounded-full transition-colors duration-200"
              >
                Login
              </a>
              <a
                href="#"
                className="px-4 py-2 text-sm font-medium bg-primary hover:bg-primary/90 text-primary-foreground rounded-full shadow hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5"
              >
                Sign Up
              </a>
            </div>

            {/* Hamburger Menu Button with Animation */}
            <button
              className={`hamburger relative h-6 w-6 md:hidden focus:outline-none ${
                isMenuOpen ? "active" : ""
              }`}
              aria-label="Toggle navigation menu"
              aria-expanded={isMenuOpen}
              aria-controls="nav-menu"
              onClick={toggleMenu}
            >
              <span className="hamburger-line top-0"></span>
              <span className="hamburger-line top-[9px]"></span>
              <span className="hamburger-line top-[18px]"></span>
            </button>
          </div>
        </nav>
      </div>

      {/* Mobile Navigation Menu */}
      <div
        id="nav-menu"
        className={`mobile-nav ${isMenuOpen ? "active" : ""}`}
      >
        <button
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
          onClick={toggleMenu}
          aria-label="Close menu"
        >
          <X className="h-6 w-6" />
        </button>
        <ul className="flex flex-col space-y-4">
          <li>
            <a 
              href="#templates"
              className="block px-4 py-2 rounded-md hover:bg-muted transition-colors duration-200"
              onClick={toggleMenu}
            >
              Templates
            </a>
          </li>
          <li>
            <a 
              href="#pricing"
              className="block px-4 py-2 rounded-md hover:bg-muted transition-colors duration-200"
              onClick={toggleMenu}
            >
              Pricing
            </a>
          </li>
          <li>
            <a 
              href="#faq"
              className="block px-4 py-2 rounded-md hover:bg-muted transition-colors duration-200"
              onClick={toggleMenu}
            >
              FAQ
            </a>
          </li>
          <li className="pt-4 border-t border-border">
            <a 
              href="#"
              className="block px-4 py-2 rounded-md border border-primary text-primary text-center"
              onClick={toggleMenu}
            >
              Login
            </a>
          </li>
          <li className="pt-2">
            <a 
              href="#"
              className="block px-4 py-2 rounded-md bg-primary hover:bg-primary/90 text-white text-center shadow"
              onClick={toggleMenu}
            >
              Sign Up
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
