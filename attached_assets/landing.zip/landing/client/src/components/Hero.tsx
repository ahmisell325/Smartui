import { ArrowRight, Check, Clock, Users, Zap } from "lucide-react";

export default function Hero() {
  return (
    <section id="hero" className="pt-28 md:pt-32 pb-16 md:pb-20 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-center">
          <div className="lg:col-span-3 max-w-xl mx-auto lg:mx-0">
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <div className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-primary/80 to-primary text-white rounded-full shadow-sm animate-pulse">
                <span className="inline-block animate-pulse">🔥</span> Special Launch Offer - 30% Off All Plans
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">Launch Stunning Landing Pages</span> in Minutes
            </h1>
            <p className="text-lg text-muted-foreground mb-6">High-converting, fully responsive landing page templates ready for customization and instant deployment. Trusted by startups and enterprises alike.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-start">
                <div className="mr-2 mt-1 bg-green-100 dark:bg-green-800/30 p-1 rounded-full">
                  <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="font-medium text-sm">30%+ Conversion Rate</p>
                  <p className="text-xs text-muted-foreground">Optimized for maximum results</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="mr-2 mt-1 bg-blue-100 dark:bg-blue-800/30 p-1 rounded-full">
                  <Clock className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <p className="font-medium text-sm">Launch in 5 Minutes</p>
                  <p className="text-xs text-muted-foreground">No coding skills required</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="mr-2 mt-1 bg-purple-100 dark:bg-purple-800/30 p-1 rounded-full">
                  <Users className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <p className="font-medium text-sm">1000+ Happy Customers</p>
                  <p className="text-xs text-muted-foreground">Join our satisfied community</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="mr-2 mt-1 bg-amber-100 dark:bg-amber-800/30 p-1 rounded-full">
                  <Zap className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="font-medium text-sm">Unlimited Downloads</p>
                  <p className="text-xs text-muted-foreground">All templates included</p>
                </div>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-4 mb-8">
              <a 
                href="#pricing" 
                className="px-8 py-4 bg-gradient-to-r from-primary to-primary/90 text-white font-medium rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 flex items-center group"
              >
                <span className="mr-2">Get Started Today</span>
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="#templates" 
                className="px-8 py-4 bg-background dark:bg-gray-800 text-primary border-2 border-primary font-medium rounded-full hover:bg-muted dark:hover:bg-gray-700 transition-colors duration-200 flex items-center"
              >
                Browse Templates
              </a>
            </div>
            
            <div className="text-sm text-muted-foreground flex items-center">
              <svg className="w-5 h-5 text-yellow-400 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              <span className="font-bold">4.9/5</span>
              <span className="mx-1">·</span> 
              <span>2.5k+ five-star reviews</span>
              <span className="mx-1">·</span>
              <span className="text-green-600 dark:text-green-400 font-medium">30-day money back</span>
            </div>
          </div>
          <div className="lg:col-span-2">
            <div className="relative">
              <div className="absolute -top-6 -left-6 bg-secondary text-white px-4 py-2 text-sm font-semibold rounded-lg shadow-lg rotate-[-2deg] z-10">
                Most Popular Template
              </div>
              <img 
                src="https://images.unsplash.com/photo-1517292987719-0369a794ec0f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Professional landing page template preview with analytics dashboard" 
                className="rounded-lg shadow-xl w-full object-cover transform hover:scale-[1.02] transition-transform duration-300 border-4 border-white dark:border-gray-800"
                loading="eager"
                width="800"
                height="600"
              />
              <div className="absolute -bottom-4 -right-4 bg-background dark:bg-gray-800 p-3 rounded-lg shadow-lg flex items-center space-x-2">
                <div className="bg-green-100 dark:bg-green-800/30 p-2 rounded-full">
                  <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
                </div>
                <span className="font-medium text-sm">Ready to Launch</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
