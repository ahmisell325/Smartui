import { useState, useEffect } from "react";
import { Cookie } from "lucide-react";

export default function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if user has already accepted cookies
    const cookiesAccepted = localStorage.getItem("cookiesAccepted");
    
    // Show banner after a small delay if cookies haven't been accepted
    if (!cookiesAccepted) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookiesAccepted", "true");
    setIsVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem("cookiesAccepted", "false");
    setIsVisible(false);
  };

  return (
    <div 
      className={`fixed bottom-0 left-0 w-full bg-background shadow-md p-4 z-50 transition-all duration-300 transform ${
        isVisible ? "translate-y-0" : "translate-y-full"
      }`}
      role="dialog" 
      aria-live="polite"
    >
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-start">
            <Cookie className="h-6 w-6 text-muted-foreground mt-1 mr-3" />
            <div>
              <p className="text-foreground mb-1">We use cookies to enhance your experience.</p>
              <p className="text-sm text-muted-foreground">
                This site uses cookies for analytics, personalized content and ads. 
                By continuing to browse this site, you agree to this use.
              </p>
            </div>
          </div>
          <div className="flex flex-shrink-0 gap-2">
            <button 
              onClick={handleDecline}
              className="px-4 py-2 bg-muted hover:bg-muted/70 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg transition-colors duration-200"
            >
              Decline
            </button>
            <button 
              onClick={handleAccept}
              className="px-4 py-2 bg-primary hover:bg-primary/90 text-white rounded-lg transition-colors duration-200"
            >
              Accept All
            </button>
            <a 
              href="#" 
              className="px-4 py-2 text-primary hover:underline"
            >
              Cookie Settings
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
