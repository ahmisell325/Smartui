import { Facebook, Twitter, Instagram, Linkedin, Lock, ShieldCheck } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-800 dark:bg-gray-900 text-white pt-16 pb-8 transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-6">
              <span className="text-2xl font-bold text-white">PageMart</span>
              <span className="ml-2 bg-primary text-white text-xs px-2 py-1 rounded-full">v2.0</span>
            </div>
            <p className="text-gray-300 mb-6">Your source for premium landing page templates that convert.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200" aria-label="PageMart on Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200" aria-label="PageMart on Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200" aria-label="PageMart on Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors duration-200" aria-label="PageMart on LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Templates</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Browse All</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">SaaS Templates</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">E-commerce</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Marketing</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Portfolio</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">About Us</a></li>
              <li><a href="#pricing" className="text-gray-300 hover:text-white transition-colors duration-200">Pricing</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Careers</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Blog</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#faq" className="text-gray-300 hover:text-white transition-colors duration-200">FAQ</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Help Center</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Documentation</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">API Guide</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors duration-200">Status</a></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-700 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-gray-400">&copy; {new Date().getFullYear()} PageMart. All rights reserved.</p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Cookies Policy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">GDPR</a>
            </div>
          </div>
        </div>
        
        <div className="mt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0 flex items-center flex-wrap gap-4">
            <div className="flex items-center">
              <Lock className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-sm text-gray-400">Secure Payment</span>
            </div>
            <div className="flex items-center">
              <ShieldCheck className="h-4 w-4 text-gray-400 mr-2" />
              <span className="text-sm text-gray-400">GDPR Compliant</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <img src="https://cdn.jsdelivr.net/npm/payment-icons/min/flat/visa.svg" alt="Visa" className="h-6 object-contain" />
            <img src="https://cdn.jsdelivr.net/npm/payment-icons/min/flat/mastercard.svg" alt="Mastercard" className="h-6 object-contain" />
            <img src="https://cdn.jsdelivr.net/npm/payment-icons/min/flat/amex.svg" alt="American Express" className="h-6 object-contain" />
            <img src="https://cdn.jsdelivr.net/npm/payment-icons/min/flat/paypal.svg" alt="PayPal" className="h-6 object-contain" />
          </div>
        </div>
      </div>
    </footer>
  );
}
