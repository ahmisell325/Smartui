import { useState } from "react";
import { ChevronDown } from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: "What payment methods are accepted?",
    answer: "We accept all major credit cards (Visa, MasterCard, American Express, Discover), PayPal, and Stripe. For enterprise plans, we also support invoicing and bank transfers. All payments are processed securely through our PCI-compliant payment providers."
  },
  {
    question: "Can I cancel anytime?",
    answer: "Yes, subscription plans can be cancelled at any time from your account dashboard. After cancellation, you'll continue to have access to your plan until the end of your current billing period. We don't offer prorated refunds for partial months."
  },
  {
    question: "Are the templates customizable?",
    answer: "Absolutely! All our templates are fully customizable. You can modify colors, fonts, layouts, and content to match your brand. Our templates work with popular page builders and CMS platforms including WordPress, Webflow, and Shopify."
  },
  {
    question: "Do you offer refunds?",
    answer: "We offer a 30-day money-back guarantee for all our plans. If you're not satisfied with our templates or service, contact our support team within 30 days of purchase for a full refund, no questions asked."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  const toggleFAQ = (index: number) => {
    setOpenIndex(index === openIndex ? -1 : index);
  };

  return (
    <section id="faq" className="py-16 md:py-24 bg-background transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="max-w-2xl mx-auto text-muted-foreground">
            Find answers to common questions about our templates and services.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <div className="grid gap-6">
            {faqs.map((faq, index) => (
              <div 
                key={index} 
                className="bg-muted/50 dark:bg-gray-750 rounded-lg p-6 transition-all duration-300 hover:shadow-md"
              >
                <button 
                  className="flex justify-between items-center w-full text-left focus:outline-none"
                  onClick={() => toggleFAQ(index)}
                  aria-expanded={index === openIndex}
                  aria-controls={`faq-answer-${index}`}
                >
                  <h3 className="font-semibold text-lg pr-8">{faq.question}</h3>
                  <ChevronDown className={`h-5 w-5 text-muted-foreground transition-transform duration-200 ${
                    index === openIndex ? "transform rotate-180" : ""
                  }`} />
                </button>
                <div 
                  id={`faq-answer-${index}`}
                  className={`mt-4 text-muted-foreground transition-all duration-300 overflow-hidden ${
                    index === openIndex ? "max-h-96" : "max-h-0"
                  }`}
                >
                  <p>{faq.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
