import { useState, useEffect, useRef } from "react";
import { X, Lock } from "lucide-react";

export default function PlanModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState({
    name: "",
    price: "",
    period: "",
    total: ""
  });
  const [isChecked, setIsChecked] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);

  // Handle plan selection
  useEffect(() => {
    const handlePlanSelection = (e: Event) => {
      const target = e.target as HTMLElement;
      const planButton = target.closest('[data-event="click:handlePlanSelection"]');
      
      if (planButton) {
        e.preventDefault();
        
        const plan = planButton.getAttribute("data-plan") || "";
        let name = "";
        let price = "";
        
        // Get plan details based on the selected plan
        switch (plan) {
          case "basic":
            name = "Basic License";
            price = document.getElementById("basic-price")?.textContent || "$14.99";
            break;
          case "pro":
            name = "Pro License";
            price = document.getElementById("pro-price")?.textContent || "$49.00";
            break;
          case "agency":
            name = "Agency License";
            price = document.getElementById("agency-price")?.textContent || "$99.00";
            break;
        }
        
        // Get the billing period
        const savedPeriod = localStorage.getItem("pricingPeriod") || "monthly";
        let periodLabel = "";
        
        switch (savedPeriod) {
          case "monthly":
            periodLabel = "Monthly billing";
            break;
          case "semiannual":
            periodLabel = "Semi-annual billing";
            break;
          case "annual":
            periodLabel = "Annual billing";
            break;
        }
        
        setSelectedPlan({
          name,
          price,
          period: periodLabel,
          total: price
        });
        
        setIsOpen(true);
      }
    };
    
    document.addEventListener("click", handlePlanSelection);
    return () => document.removeEventListener("click", handlePlanSelection);
  }, []);

  // Handle click outside modal to close
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        closeModal();
      }
    };
    
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  // Handle ESC key to close modal
  useEffect(() => {
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        closeModal();
      }
    };
    
    if (isOpen) {
      document.addEventListener("keydown", handleEscKey);
    }
    
    return () => {
      document.removeEventListener("keydown", handleEscKey);
    };
  }, [isOpen]);

  const closeModal = () => {
    setIsOpen(false);
    setIsChecked(false);
  };

  return (
    <div 
      className={`fixed inset-0 bg-black/50 flex items-center justify-center z-50 transition-opacity duration-300 ${
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}
      role="dialog" 
      aria-modal="true" 
      aria-labelledby="modal-title"
    >
      <div 
        ref={modalRef}
        className={`bg-card rounded-xl shadow-lg max-w-md w-full mx-4 transition-transform duration-300 transform ${
          isOpen ? "scale-100" : "scale-95"
        }`}
      >
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 id="modal-title" className="text-xl font-bold">Confirm Your Selection</h3>
            <button 
              onClick={closeModal}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="mb-6">
            <p className="text-muted-foreground mb-4">
              You're about to select the <span className="font-semibold">{selectedPlan.name}</span> plan.
            </p>
            <div className="bg-muted/50 p-4 rounded-lg mb-4">
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Plan price:</span>
                <span className="font-medium">{selectedPlan.price}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Billing period:</span>
                <span className="font-medium">{selectedPlan.period}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-border">
                <span className="font-medium">Total today:</span>
                <span className="font-bold">{selectedPlan.total}</span>
              </div>
            </div>
            <div className="flex items-center text-sm text-muted-foreground mb-6">
              <Lock className="h-4 w-4 text-green-500 mr-2" />
              <span>Secure checkout with SSL encryption</span>
            </div>
            <div className="flex items-start mb-4">
              <input 
                type="checkbox" 
                id="terms-checkbox" 
                checked={isChecked}
                onChange={(e) => setIsChecked(e.target.checked)}
                className="mt-1 mr-2"
              />
              <label htmlFor="terms-checkbox" className="text-sm text-muted-foreground">
                I agree to the <a href="#" className="text-primary hover:underline">Terms of Service</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>
              </label>
            </div>
          </div>
          <div className="flex flex-col space-y-3">
            <button 
              className={`w-full bg-primary text-white font-medium py-2 px-4 rounded-lg flex items-center justify-center ${
                isChecked 
                  ? "hover:bg-primary/90 transition-colors duration-200" 
                  : "opacity-50 cursor-not-allowed"
              }`}
              disabled={!isChecked}
            >
              <span>Proceed to Checkout</span>
              <Lock className="h-4 w-4 ml-2" />
            </button>
            <button 
              onClick={closeModal}
              className="w-full bg-muted hover:bg-muted/70 dark:bg-gray-700 dark:hover:bg-gray-600 text-foreground font-medium py-2 px-4 rounded-lg transition-colors duration-200"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
