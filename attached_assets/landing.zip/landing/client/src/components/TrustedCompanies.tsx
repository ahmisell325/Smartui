import React from "react";

export default function TrustedCompanies() {
  const companies = [
    { name: "Acme Corp", logo: generateCompanyLogo("A") },
    { name: "Globex", logo: generateCompanyLogo("G") },
    { name: "Soylent Corp", logo: generateCompanyLogo("S") },
    { name: "Initech", logo: generateCompanyLogo("I") },
    { name: "Umbrella Corp", logo: generateCompanyLogo("U") },
    { name: "Hooli", logo: generateCompanyLogo("H") },
  ];

  return (
    <div className="py-10 bg-muted/50 dark:bg-gray-900/50 transition-colors duration-300">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-lg font-medium text-muted-foreground">
            Trusted by Leading Companies
          </h2>
        </div>
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
          {companies.map((company, index) => (
            <div 
              key={index} 
              className="flex items-center justify-center grayscale opacity-70 hover:opacity-100 hover:grayscale-0 transition-all duration-300 dark:invert-[0.8] dark:hue-rotate-180"
              title={company.name}
            >
              <div dangerouslySetInnerHTML={{ __html: company.logo }} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function generateCompanyLogo(letter: string) {
  // Generate a simple SVG logo with the first letter
  const colors = [
    { main: "#4f46e5", light: "#c7d2fe" }, // Indigo
    { main: "#2563eb", light: "#bfdbfe" }, // Blue
    { main: "#0891b2", light: "#a5f3fc" }, // Cyan
    { main: "#059669", light: "#a7f3d0" }, // Emerald
    { main: "#65a30d", light: "#d9f99d" }, // Lime
    { main: "#b45309", light: "#fde68a" }, // Amber
  ];
  
  // Select a random color from the array
  const colorIndex = Math.floor(Math.random() * colors.length);
  const color = colors[colorIndex];
  
  // Generate simple SVG logo with light/dark mode support
  return `
    <svg width="120" height="40" viewBox="0 0 120 40" xmlns="http://www.w3.org/2000/svg">
      <style>
        @media (prefers-color-scheme: dark) {
          .logo-bg { fill: rgba(45, 45, 60, 0.4); }
          .logo-text { fill: ${color.light}; }
        }
      </style>
      <rect width="120" height="40" rx="4" class="logo-bg" fill="${color.light}" />
      <text x="60" y="28" font-family="Arial, sans-serif" font-size="24" font-weight="bold" class="logo-text" fill="${color.main}" text-anchor="middle">
        ${letter}Corp
      </text>
    </svg>
  `;
}