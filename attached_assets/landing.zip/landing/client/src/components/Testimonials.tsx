import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Check, Star } from "lucide-react";

interface Testimonial {
  id: number;
  avatar: string;
  name: string;
  role: string;
  company: {
    name: string;
    logo: string;
  };
  rating: number;
  quote: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    name: "Alex R.",
    role: "Marketing Manager",
    company: {
      name: "TechFlow",
      logo: "https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/prisma.svg"
    },
    rating: 5,
    quote: "PageMart saved us hours of design time and boosted conversions by 30%! The templates were easy to customize and our clients were impressed with the professional results."
  },
  {
    id: 2,
    avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    name: "Jamie L.",
    role: "Freelance Designer",
    company: {
      name: "Studio Creative",
      logo: "https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/dribbble.svg"
    },
    rating: 5,
    quote: "The templates are beautiful and easy to customize. I was able to create a stunning landing page for my business in just a few hours, and I've seen a significant increase in leads since launching."
  },
  {
    id: 3,
    avatar: "https://randomuser.me/api/portraits/women/55.jpg",
    name: "Priya S.",
    role: "Startup Founder",
    company: {
      name: "InnovateCo",
      logo: "https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/vercel.svg"
    },
    rating: 4.5,
    quote: "Excellent support and continuous updates. We've been using PageMart templates for our startup's landing pages and have been impressed with the regular improvements and responsive support team."
  }
];

export default function Testimonials() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const nextSlide = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentSlide((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentSlide((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToSlide = (index: number) => {
    if (isTransitioning || index === currentSlide) return;
    
    setIsTransitioning(true);
    setCurrentSlide(index);
  };

  // Auto-advance slides
  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [currentSlide, isTransitioning]);

  // Reset transition state
  useEffect(() => {
    if (isTransitioning) {
      const timer = setTimeout(() => setIsTransitioning(false), 400);
      return () => clearTimeout(timer);
    }
  }, [isTransitioning]);

  // Render stars for rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={`full-${i}`} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
      );
    }
    
    if (hasHalfStar) {
      stars.push(
        <svg key="half" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" className="h-4 w-4 text-yellow-400">
          <path fill="currentColor" d="M12 2L9.1 9.1H2l5.8 4.9-2.3 7.1 6.5-4.9 6.5 4.9-2.3-7.1 5.8-4.9h-7.1L12 2z"/>
          <path fill="currentColor" d="M12 2v14l-6.5 4.9 2.3-7.1L2 9.1h7.1L12 2z"/>
        </svg>
      );
    }
    
    // Add empty stars to make total of 5
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Star key={`empty-${i}`} className="h-4 w-4 text-yellow-400" />
      );
    }
    
    return stars;
  };

  return (
    <section id="testimonials" className="py-16 md:py-24 bg-background transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
          <p className="max-w-2xl mx-auto text-muted-foreground">
            Hear from our satisfied customers who have transformed their online presence with PageMart templates.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto">
          <div className="carousel">
            <button 
              className="absolute left-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-background dark:bg-gray-700 rounded-full shadow-md flex items-center justify-center z-10 focus:outline-none focus:ring-2 focus:ring-primary dark:focus:ring-primary/80 hover:bg-muted transition-colors duration-200"
              aria-label="Previous testimonial"
              onClick={prevSlide}
            >
              <ChevronLeft className="h-5 w-5 text-muted-foreground" />
            </button>
            
            <div className="slides overflow-hidden min-h-[360px] md:min-h-[300px]">
              {testimonials.map((testimonial, index) => (
                <article 
                  key={testimonial.id}
                  className={`testimonial-slide absolute inset-0 transition-all duration-300 ${
                    index === currentSlide ? "opacity-100 z-10 relative" : "opacity-0 z-0"
                  }`}
                >
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex-shrink-0 flex flex-col items-center">
                      <img 
                        src={testimonial.avatar} 
                        alt={`${testimonial.name}'s profile picture`} 
                        className="w-20 h-20 rounded-full object-cover border-4 border-background dark:border-gray-700 shadow-md"
                        width="80" height="80"
                        loading="lazy"
                      />
                      <div className="mt-4 flex">
                        {renderStars(testimonial.rating)}
                      </div>
                      <div className="mt-2 flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span className="text-xs text-muted-foreground">Verified Customer</span>
                      </div>
                    </div>
                    
                    <div>
                      <div className="relative">
                        <svg className="h-8 w-8 absolute -top-4 -left-2 text-muted opacity-20" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                        </svg>
                        <p className="text-lg italic mb-6 relative z-10">{testimonial.quote}</p>
                      </div>
                      <div className="mt-4">
                        <div className="font-semibold">{testimonial.name}</div>
                        <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                        <div className="flex items-center mt-2">
                          <img 
                            src={testimonial.company.logo} 
                            alt={`${testimonial.company.name} logo`} 
                            className="h-5 object-contain" 
                            width="120" height="40"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            
            <button 
              className="absolute right-0 top-1/2 -translate-y-1/2 w-10 h-10 bg-background dark:bg-gray-700 rounded-full shadow-md flex items-center justify-center z-10 focus:outline-none focus:ring-2 focus:ring-primary dark:focus:ring-primary/80 hover:bg-muted transition-colors duration-200"
              aria-label="Next testimonial"
              onClick={nextSlide}
            >
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            
            <div className="flex justify-center mt-6 space-x-2">
              {testimonials.map((_, index) => (
                <button 
                  key={index}
                  className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                    index === currentSlide ? "bg-primary" : "bg-muted-foreground/30"
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                  onClick={() => goToSlide(index)}
                />
              ))}
            </div>
          </div>
        </div>
        
        {/* Featured In */}
        <div className="mt-20">
          <div className="text-center mb-8">
            <h3 className="text-xl font-bold">As Featured In</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
            <img 
              src="https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/techcrunch.svg" 
              alt="TechCrunch logo" 
              className="h-8 md:h-10 object-contain mx-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all duration-300" 
              loading="lazy" 
              width="150" 
              height="75"
            />
            <img 
              src="https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/forbes.svg" 
              alt="Forbes logo" 
              className="h-8 md:h-10 object-contain mx-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all duration-300" 
              loading="lazy" 
              width="150" 
              height="75"
            />
            <img 
              src="https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/wired.svg" 
              alt="Wired logo" 
              className="h-8 md:h-10 object-contain mx-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all duration-300" 
              loading="lazy" 
              width="150" 
              height="75"
            />
            <img 
              src="https://cdn.jsdelivr.net/npm/simple-icons@v7/icons/entrepreneur.svg" 
              alt="Entrepreneur logo" 
              className="h-8 md:h-10 object-contain mx-auto grayscale opacity-70 hover:grayscale-0 hover:opacity-100 transition-all duration-300" 
              loading="lazy" 
              width="150" 
              height="75"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
