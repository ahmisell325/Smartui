export default function CTA() {
  return (
    <section className="py-16 md:py-24 bg-primary dark:bg-primary/80 text-white relative overflow-hidden transition-colors duration-300">
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <svg width="100%" height="100%" viewBox="0 0 800 800" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 0h800v800H0z" fill="none"/>
          <g fill="none" stroke="#FFF" strokeWidth="2">
            <path d="M769 229L1037 260.9M927 880L731 737 520 660 309 538 40 599 295 764"/>
            <path d="M-11 369L-11 469 111 531 301 500 371 660 559 664 588 796 380 850 108 865"/>
            <path d="M-11 369L111 215 211 191 401 221 371 531 371 586 511 640 593 796 400 850"/>
          </g>
        </svg>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Get Started with PageMart Today</h2>
          <p className="text-lg mb-8">
            Empower your business with professional landing page templates and start seeing results in days, not months.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a 
              href="#pricing" 
              className="px-8 py-3 bg-white text-primary font-medium rounded-full shadow hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5"
            >
              See Pricing Plans
            </a>
            <a 
              href="#templates" 
              className="px-8 py-3 bg-transparent border-2 border-white text-white font-medium rounded-full hover:bg-white/10 transition-all duration-200"
            >
              Browse Templates
            </a>
          </div>
          
          <div className="flex items-center justify-center mt-8">
            <div className="flex -space-x-2">
              <img 
                src="https://randomuser.me/api/portraits/women/32.jpg" 
                alt="User avatar" 
                className="w-10 h-10 rounded-full border-2 border-white" 
                width="40" 
                height="40"
                loading="lazy"
              />
              <img 
                src="https://randomuser.me/api/portraits/men/44.jpg" 
                alt="User avatar" 
                className="w-10 h-10 rounded-full border-2 border-white" 
                width="40" 
                height="40" 
                loading="lazy"
              />
              <img 
                src="https://randomuser.me/api/portraits/women/56.jpg" 
                alt="User avatar" 
                className="w-10 h-10 rounded-full border-2 border-white" 
                width="40" 
                height="40" 
                loading="lazy"
              />
              <img 
                src="https://randomuser.me/api/portraits/men/78.jpg" 
                alt="User avatar" 
                className="w-10 h-10 rounded-full border-2 border-white" 
                width="40" 
                height="40" 
                loading="lazy"
              />
              <span className="w-10 h-10 rounded-full border-2 border-white bg-primary-foreground/80 flex items-center justify-center text-xs font-bold text-primary">
                +2k
              </span>
            </div>
            <p className="ml-4 text-sm">Joined this month</p>
          </div>
        </div>
      </div>
    </section>
  );
}
