import { useState, useEffect } from "react";
import { ArrowRight, Check, Info, Tag, ShieldCheck, Lock, Users } from "lucide-react";
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

type PricingPeriod = "monthly" | "semiannual" | "annual";

interface PricingPlan {
  id: number;
  name: string;
  slug: string;
  description: string;
  monthlyPrice: string | number;
  semiannualPrice: string | number;
  annualPrice: string | number;
  features: string[];
  popular?: boolean;
  badge?: string | null;
  buttonText: string;
}

// Fetch pricing plans from the API
const usePricingPlans = () => {
  return useQuery({
    queryKey: ['/api/pricing'],
    queryFn: async () => {
      const response = await apiRequest<{ success: boolean; data: PricingPlan[] }>('/api/pricing');
      return response.data;
    },
  });
};

export default function Pricing() {
  const [activePeriod, setActivePeriod] = useState<PricingPeriod>("monthly");
  const [customTemplates, setCustomTemplates] = useState<number>(10);
  const [hasError, setHasError] = useState<boolean>(false);
  const [animatePrice, setAnimatePrice] = useState<boolean>(false);
  
  // Fetch plans from database
  const { data: plans = [], isLoading, error } = usePricingPlans();

  const handlePeriodChange = (period: PricingPeriod) => {
    setAnimatePrice(true);
    setActivePeriod(period);
    // Store preference
    localStorage.setItem("pricingPeriod", period);
  };

  const handleCustomTemplatesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    
    if (isNaN(value) || value < 10) {
      setHasError(true);
    } else {
      setHasError(false);
    }
    
    setCustomTemplates(value);
  };

  // Calculate custom plan prices
  const monthlyRate = 9.99;
  const annualRate = 9.29;
  const monthlyTotal = isNaN(customTemplates) ? 0 : customTemplates * monthlyRate;
  const annualTotal = isNaN(customTemplates) ? 0 : customTemplates * annualRate * 12;
  const regularAnnualTotal = isNaN(customTemplates) ? 0 : customTemplates * monthlyRate * 12;
  const savings = regularAnnualTotal - annualTotal;

  // Initialize with saved preference
  useEffect(() => {
    const savedPeriod = localStorage.getItem("pricingPeriod") as PricingPeriod | null;
    if (savedPeriod && ["monthly", "semiannual", "annual"].includes(savedPeriod)) {
      setActivePeriod(savedPeriod);
    }
  }, []);

  // Reset price animation
  useEffect(() => {
    if (animatePrice) {
      const timer = setTimeout(() => setAnimatePrice(false), 300);
      return () => clearTimeout(timer);
    }
  }, [animatePrice]);

  const getPrice = (plan: PricingPlan) => {
    switch (activePeriod) {
      case "monthly": return plan.monthlyPrice;
      case "semiannual": return plan.semiannualPrice;
      case "annual": return plan.annualPrice;
    }
  };

  const getBillingLabel = () => {
    switch (activePeriod) {
      case "monthly": return "/month";
      case "semiannual": return "/month billed semi-annually";
      case "annual": return "/month billed annually";
    }
  };

  const getSavingsPercentage = (period: PricingPeriod) => {
    switch (period) {
      case "monthly": return null;
      case "semiannual": return 10;
      case "annual": return 20;
    }
  };

  return (
    <section id="pricing" className="py-16 md:py-24 bg-muted transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Pricing Plans</h2>
          <p className="max-w-2xl mx-auto text-muted-foreground">
            Choose the perfect plan for your needs. All plans include updates and basic support.
          </p>
        </div>
        
        {/* Free Trial Card */}
        <div className="max-w-sm mx-auto mb-12">
          <div className="pricing-card border-2 border-dashed border-secondary relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 bg-secondary text-white px-3 py-1 text-sm font-medium">Limited time</div>
            <h3 className="text-xl font-bold mb-2">Free Trial</h3>
            <p className="text-muted-foreground mb-4">Sample Template Access</p>
            <div className="flex justify-center items-baseline mb-6">
              <span className="text-3xl font-extrabold">$0</span>
              <span className="text-muted-foreground ml-1">/one-time</span>
            </div>
            <ul className="space-y-3 mb-6 text-left">
              {["1 free template download", "Community support", "Basic customization"].map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <a 
              href="#" 
              className="block w-full bg-secondary hover:bg-secondary/90 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200 shadow hover:shadow-lg"
            >
              Start Free Trial
            </a>
          </div>
        </div>
        
        {/* Pricing Toggle */}
        <div className="flex justify-center mb-12 relative overflow-x-auto md:overflow-visible">
          <div 
            className="inline-flex p-1 bg-muted-foreground/10 rounded-full" 
            role="tablist" 
            aria-label="Billing period selection"
          >
            <button 
              className={`text-sm px-6 py-2 font-medium rounded-full transition-all duration-300 ${
                activePeriod === "monthly" 
                  ? "bg-background dark:bg-gray-800 shadow" 
                  : "text-muted-foreground hover:bg-background/50 dark:hover:bg-gray-800/50"
              }`}
              role="tab"
              aria-selected={activePeriod === "monthly"}
              aria-controls="monthly-pricing"
              onClick={() => handlePeriodChange("monthly")}
            >
              Monthly
            </button>
            <button 
              className={`text-sm px-6 py-2 font-medium rounded-full transition-all duration-300 ${
                activePeriod === "semiannual" 
                  ? "bg-background dark:bg-gray-800 shadow" 
                  : "text-muted-foreground hover:bg-background/50 dark:hover:bg-gray-800/50"
              }`}
              role="tab"
              aria-selected={activePeriod === "semiannual"}
              aria-controls="semiannual-pricing"
              onClick={() => handlePeriodChange("semiannual")}
            >
              6 Months <span className="ml-1 text-xs text-primary">Save 10%</span>
            </button>
            <button 
              className={`text-sm px-6 py-2 font-medium rounded-full transition-all duration-300 ${
                activePeriod === "annual" 
                  ? "bg-background dark:bg-gray-800 shadow" 
                  : "text-muted-foreground hover:bg-background/50 dark:hover:bg-gray-800/50"
              }`}
              role="tab"
              aria-selected={activePeriod === "annual"}
              aria-controls="annual-pricing"
              onClick={() => handlePeriodChange("annual")}
            >
              Annually <span className="ml-1 text-xs text-primary">Save 20%</span>
            </button>
          </div>
        </div>
        
        {/* Pricing Cards */}
        <div 
          role="tabpanel" 
          aria-labelledby={`${activePeriod}-tab`}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto"
        >
          {isLoading ? (
            // Loading state
            <>
              <div className="pricing-card animate-pulse bg-muted/50">
                <div className="h-6 w-24 bg-muted-foreground/20 rounded mb-2"></div>
                <div className="h-4 w-32 bg-muted-foreground/20 rounded mb-6"></div>
                <div className="h-8 w-20 bg-muted-foreground/20 rounded mb-8"></div>
                <div className="space-y-2 mb-6">
                  <div className="h-4 w-full bg-muted-foreground/20 rounded"></div>
                  <div className="h-4 w-full bg-muted-foreground/20 rounded"></div>
                  <div className="h-4 w-3/4 bg-muted-foreground/20 rounded"></div>
                </div>
                <div className="h-10 w-full bg-muted-foreground/20 rounded"></div>
              </div>
              <div className="pricing-card animate-pulse bg-muted/50">
                <div className="h-6 w-24 bg-muted-foreground/20 rounded mb-2"></div>
                <div className="h-4 w-32 bg-muted-foreground/20 rounded mb-6"></div>
                <div className="h-8 w-20 bg-muted-foreground/20 rounded mb-8"></div>
                <div className="space-y-2 mb-6">
                  <div className="h-4 w-full bg-muted-foreground/20 rounded"></div>
                  <div className="h-4 w-full bg-muted-foreground/20 rounded"></div>
                  <div className="h-4 w-3/4 bg-muted-foreground/20 rounded"></div>
                </div>
                <div className="h-10 w-full bg-muted-foreground/20 rounded"></div>
              </div>
              <div className="pricing-card animate-pulse bg-muted/50">
                <div className="h-6 w-24 bg-muted-foreground/20 rounded mb-2"></div>
                <div className="h-4 w-32 bg-muted-foreground/20 rounded mb-6"></div>
                <div className="h-8 w-20 bg-muted-foreground/20 rounded mb-8"></div>
                <div className="space-y-2 mb-6">
                  <div className="h-4 w-full bg-muted-foreground/20 rounded"></div>
                  <div className="h-4 w-full bg-muted-foreground/20 rounded"></div>
                  <div className="h-4 w-3/4 bg-muted-foreground/20 rounded"></div>
                </div>
                <div className="h-10 w-full bg-muted-foreground/20 rounded"></div>
              </div>
            </>
          ) : error ? (
            // Error state
            <div className="col-span-3 text-center p-8 bg-destructive/10 rounded-lg">
              <p className="text-destructive font-medium mb-2">Failed to load pricing plans</p>
              <p className="text-sm text-muted-foreground">Please try refreshing the page</p>
            </div>
          ) : (
            // Loaded plans
            plans.map((plan, index) => {
              // Parse price values to ensure they're numbers for toFixed
              const monthlyPrice = typeof plan.monthlyPrice === 'string' ? parseFloat(plan.monthlyPrice) : plan.monthlyPrice;
              const semiannualPrice = typeof plan.semiannualPrice === 'string' ? parseFloat(plan.semiannualPrice) : plan.semiannualPrice;
              const annualPrice = typeof plan.annualPrice === 'string' ? parseFloat(plan.annualPrice) : plan.annualPrice;
              
              // Create a simplified plan object with numeric prices
              const planWithParsedPrices = {
                ...plan,
                monthlyPrice,
                semiannualPrice,
                annualPrice
              };
              
              return (
                <div 
                  key={index} 
                  className={`pricing-card relative transform transition-all duration-300 hover:translate-y-[-8px] hover:shadow-xl ${
                    plan.popular 
                      ? "popular border-primary before:absolute before:top-[-12px] before:left-1/2 before:transform before:translate-x-[-50%] before:content-[''] before:border-t-[12px] before:border-l-[12px] before:border-r-[12px] before:border-t-primary before:border-l-transparent before:border-r-transparent" 
                      : ""
                  }`}
                >
                  {plan.popular && plan.badge && (
                    <div className="badge absolute top-0 right-0 bg-primary text-white px-3 py-1 text-xs font-semibold rounded-bl-lg transform rotate-2 shadow-sm">
                      {plan.badge}
                    </div>
                  )}
                  
                  {plan.popular && (
                    <div className="absolute top-[-1px] left-[-1px] right-[-1px] h-[6px] bg-gradient-to-r from-primary via-primary to-secondary rounded-t-lg"></div>
                  )}
                  
                  {plan.popular && (
                    <div className="absolute top-[6px] left-0 bg-primary text-white px-3 py-1 text-xs font-medium rounded-br-lg">
                      <Users className="h-3 w-3 inline-block mr-1" /> 75% of users choose this
                    </div>
                  )}
                  
                  <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-muted-foreground mb-4">{plan.description}</p>
                  
                  <div className={`price-section ${animatePrice ? 'fade-in' : ''}`}>
                    {activePeriod !== "monthly" ? (
                      <div className="flex flex-col items-center mb-1">
                        <div className="flex items-center">
                          <span className="text-3xl font-extrabold text-primary">${typeof getPrice(planWithParsedPrices) === 'number' ? 
                            getPrice(planWithParsedPrices).toFixed(2) : 
                            parseFloat(getPrice(planWithParsedPrices) as string).toFixed(2)}</span>
                          <span className="text-muted-foreground ml-1">{getBillingLabel()}</span>
                        </div>
                        <div className="flex items-center mt-1">
                          <span className="line-through text-sm text-muted-foreground">
                            ${typeof planWithParsedPrices.monthlyPrice === 'number' ? 
                              (planWithParsedPrices.monthlyPrice * 1.25).toFixed(2) :
                              (parseFloat(planWithParsedPrices.monthlyPrice) * 1.25).toFixed(2)}
                          </span>
                          <span className="ml-2 text-xs px-2 py-0.5 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded-full">
                            Save {activePeriod === "semiannual" ? "10%" : "20%"}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <span className="text-3xl font-extrabold">${typeof getPrice(planWithParsedPrices) === 'number' ? 
                          getPrice(planWithParsedPrices).toFixed(2) : 
                          parseFloat(getPrice(planWithParsedPrices) as string).toFixed(2)}</span>
                        <span className="text-muted-foreground ml-1">{getBillingLabel()}</span>
                      </div>
                    )}
                  </div>
                  
                  <ul className="space-y-3 mb-6 flex-grow">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <div className="cta-container">
                    <a 
                      href="#" 
                      className={`block w-full font-medium py-3 px-4 rounded-lg text-center transition-all duration-300 ${
                        plan.popular 
                          ? "bg-primary hover:bg-primary/90 text-white shadow-md hover:shadow-lg hover:scale-[1.02]" 
                          : "bg-background dark:bg-gray-700 dark:hover:bg-gray-600 hover:bg-gray-50 text-primary border-2 border-primary hover:shadow-md"
                      }`}
                      data-plan={plan.id}
                      data-event="click:handlePlanSelection"
                    >
                      {plan.popular ? (
                        <span className="flex items-center justify-center">
                          {plan.buttonText} <ArrowRight className="ml-2 h-4 w-4" />
                        </span>
                      ) : plan.buttonText}
                    </a>
                    {plan.popular && (
                      <div className="text-xs text-center mt-2 text-primary font-medium">Limited time offer - Save 20%</div>
                    )}
                  </div>
                  
                  <p className="text-center text-sm text-muted-foreground mt-4">30-day money-back guarantee</p>
                </div>
              );
            })
          )}
        </div>
        
        {/* Custom Plan */}
        <div className="max-w-3xl mx-auto mt-20 bg-card rounded-xl shadow p-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h3 className="text-xl font-bold">Custom Enterprise Plan</h3>
              <p className="text-muted-foreground">Tailored solutions for larger teams</p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center">
              <div className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 text-sm font-medium px-3 py-1 rounded-full flex items-center">
                <Tag className="h-4 w-4 mr-1" />
                <span>Save up to 41%</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="mb-6">
                <p className="mb-2 text-sm text-muted-foreground">Base rate per template:</p>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold">${monthlyRate.toFixed(2)}</span>
                  <span className="line-through text-muted-foreground ml-2">$14.99</span>
                </div>
                <div className="flex items-center mt-1">
                  <div className="h-2 w-20 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-accent w-3/4"></div>
                  </div>
                  <span className="text-sm text-accent ml-2">33% off standard price</span>
                </div>
              </div>
              
              <div className="mb-6">
                <p className="mb-2 text-sm text-muted-foreground">Bulk discount rate:</p>
                <div className="flex items-baseline">
                  <span className="text-2xl font-bold">${annualRate.toFixed(2)}</span>
                  <span className="text-sm text-muted-foreground ml-2">/template (7% additional savings)</span>
                </div>
              </div>
              
              <div className="flex items-center text-sm text-muted-foreground mb-3">
                <Info className="h-4 w-4 mr-2 text-secondary" />
                <span>Volume discounts unlock at 10+ templates</span>
              </div>
              
              <ul className="space-y-2 mb-6">
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span>Includes priority support</span>
                </li>
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span>No expiration on downloads</span>
                </li>
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span>Extended license for client work</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-muted rounded-lg p-6">
              <h4 className="font-medium mb-4">Calculate your custom plan</h4>
              <form id="custom-calculator" className="space-y-4">
                <div>
                  <label htmlFor="custom-templates" className="block text-sm font-medium mb-1">
                    Number of templates needed:
                  </label>
                  <div className="relative">
                    <input 
                      type="number" 
                      id="custom-templates" 
                      min="10" 
                      value={customTemplates} 
                      onChange={handleCustomTemplatesChange}
                      className={`block w-full px-4 py-2 bg-background dark:bg-gray-700 border rounded-md shadow-sm focus:ring-primary focus:border-primary ${
                        hasError ? "border-destructive" : "border-input"
                      }`}
                      aria-describedby="template-error"
                    />
                    <div 
                      id="template-error" 
                      className={`text-destructive text-xs mt-1 ${hasError ? "block" : "hidden"}`}
                    >
                      Please enter at least 10 templates
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-border pt-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-sm">Monthly cost:</span>
                    <span className="font-medium">
                      {isNaN(monthlyTotal) || customTemplates < 10 ? 'N/A' : `$${monthlyTotal.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Annual cost:</span>
                    <span className="font-medium">
                      {isNaN(annualTotal) || customTemplates < 10 ? 'N/A' : `$${annualTotal.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between mt-2 text-green-600 dark:text-green-400 text-sm">
                    <span>Annual savings:</span>
                    <span>
                      {isNaN(savings) || customTemplates < 10 ? 'N/A' : `$${savings.toFixed(2)}`}
                    </span>
                  </div>
                </div>
                
                <div className="pt-4">
                  <a 
                    href="#" 
                    className={`block w-full bg-secondary hover:bg-secondary/90 text-white font-medium py-2 px-4 rounded-lg text-center transition-colors duration-200 shadow hover:shadow-lg ${
                      hasError || customTemplates < 10 ? "opacity-50 cursor-not-allowed" : ""
                    }`}
                    onClick={(e) => { if (hasError || customTemplates < 10) e.preventDefault(); }}
                  >
                    Request Custom Quote
                  </a>
                  <p className="text-xs text-center mt-2 text-muted-foreground">Our team will contact you within 24 hours</p>
                </div>
              </form>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-border">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center">
                <ShieldCheck className="h-4 w-4 text-secondary mr-2" />
                <span className="text-sm">Secure payment</span>
              </div>
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-secondary mr-2">
                  <path d="M3 12h4l3 8 4-16 3 8h4"/>
                </svg>
                <span className="text-sm">30-day refund</span>
              </div>
              <div className="flex items-center">
                <Lock className="h-4 w-4 text-secondary mr-2" />
                <span className="text-sm">GDPR compliant</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Trust Badges */}
        <div className="max-w-4xl mx-auto mt-16 mb-8">
          <div className="text-center mb-6">
            <h3 className="text-lg font-medium mb-2">Trusted by Teams Worldwide</h3>
            <p className="text-sm text-muted-foreground">Join thousands of satisfied customers using our templates</p>
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            <div className="flex flex-col items-center">
              <div className="bg-background dark:bg-gray-800 rounded-full p-3 shadow-sm mb-2">
                <ShieldCheck className="h-8 w-8 text-green-600" />
              </div>
              <span className="text-xs font-medium">Secure Payment</span>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-background dark:bg-gray-800 rounded-full p-3 shadow-sm mb-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                  <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
                </svg>
              </div>
              <span className="text-xs font-medium">24/7 Support</span>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-background dark:bg-gray-800 rounded-full p-3 shadow-sm mb-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-600">
                  <path d="m12 15 3.5 3.5M20 20 3.5 3.5M19 5v3h3M15 9l-3-3-7 7 3 3"/>
                </svg>
              </div>
              <span className="text-xs font-medium">Free Updates</span>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-background dark:bg-gray-800 rounded-full p-3 shadow-sm mb-2">
                <Lock className="h-8 w-8 text-indigo-600" />
              </div>
              <span className="text-xs font-medium">GDPR Compliant</span>
            </div>
          </div>
          
          <div className="flex justify-center mt-10 mb-4">
            <div className="bg-green-50 dark:bg-green-900/30 rounded-lg px-5 py-3 flex items-center shadow-sm border border-green-100 dark:border-green-800">
              <svg className="h-5 w-5 text-green-700 dark:text-green-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
              </svg>
              <p className="text-sm text-green-800 dark:text-green-300 font-medium">Money-back guarantee on all plans - 30 days risk free</p>
            </div>
          </div>
        </div>
        
        {/* VAT Notice */}
        <div className="text-center mt-6 text-sm text-muted-foreground">
          <p>All prices are exclusive of applicable taxes (VAT/GST) which will be charged at the appropriate rate.</p>
        </div>
      </div>
    </section>
  );
}
