import { useState } from "react";
import { Send, Loader2 } from "lucide-react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset states
    setError("");
    setSuccess("");
    
    // Validate email
    if (!email.trim()) {
      setError("Please enter your email address.");
      return;
    }
    
    if (!validateEmail(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    
    // Show loading state
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setSuccess("Thanks for subscribing! Please check your email for confirmation.");
      setEmail("");
      setIsSubmitted(true);
    }, 1500);
  };

  return (
    <section id="newsletter" className="py-16 md:py-20 bg-gradient-to-br from-secondary/5 to-secondary/10 dark:from-gray-800 dark:to-gray-750 transition-colors duration-300">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Stay Updated</h2>
          <p className="text-muted-foreground mb-8">
            Be the first to know about new templates, exclusive offers, and helpful resources.
          </p>
          
          <form onSubmit={handleSubmit} className="max-w-md mx-auto" noValidate>
            <div className="relative">
              <div className="flex">
                <input 
                  type="email" 
                  id="newsletter-email" 
                  placeholder="Your email address" 
                  required 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full px-4 py-3 rounded-l-lg border focus:ring-primary focus:border-primary bg-background text-foreground ${
                    error ? "border-destructive" : "border-input"
                  }`}
                  aria-describedby="newsletter-error newsletter-success"
                  disabled={isLoading || isSubmitted}
                />
                <button 
                  type="submit" 
                  className="bg-primary hover:bg-primary/90 text-white font-medium py-3 px-6 rounded-r-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:focus:ring-offset-gray-800 flex items-center disabled:opacity-70"
                  disabled={isLoading || isSubmitted}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      <span>Subscribing...</span>
                    </>
                  ) : (
                    <>
                      <span>Subscribe</span>
                      <Send className="h-4 w-4 ml-2" />
                    </>
                  )}
                </button>
              </div>
              
              {error && (
                <div 
                  id="newsletter-error" 
                  className="absolute left-0 -bottom-6 text-destructive text-sm fade-in"
                  aria-live="assertive"
                >
                  {error}
                </div>
              )}
              
              {success && (
                <div 
                  id="newsletter-success" 
                  className="absolute left-0 -bottom-6 text-green-500 text-sm fade-in"
                  aria-live="polite"
                >
                  {success}
                </div>
              )}
            </div>
            
            <p className="text-xs text-muted-foreground mt-8">
              By subscribing, you agree to our 
              <a href="#" className="underline hover:text-primary transition-colors duration-200 ml-1">
                Privacy Policy
              </a> 
              and consent to receive updates from PageMart.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
