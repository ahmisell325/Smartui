import { 
  users, type User, type InsertUser,
  newsletterSubscribers, type NewsletterSubscriber, type InsertNewsletterSubscriber,
  contactSubmissions, type ContactSubmission, type InsertContactSubmission,
  templateCategories, templates, type Template, type InsertTemplate,
  pricingPlans, type PricingPlan, type InsertPricingPlan,
  testimonials, type Testimonial, type InsertTestimonial,
  faqItems, type FaqItem, type InsertFaqItem
} from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

// Database connection using postgres.js instead of neon
// This eliminates the type compatibility issues
const connectionString = process.env.DATABASE_URL!;
const client = postgres(connectionString, { max: 1 });
const db = drizzle(client);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Newsletter operations
  subscribeToNewsletter(email: InsertNewsletterSubscriber): Promise<NewsletterSubscriber>;
  unsubscribeFromNewsletter(email: string): Promise<boolean>;
  
  // Contact form operations
  submitContactForm(submission: InsertContactSubmission): Promise<ContactSubmission>;
  
  // Template operations
  getTemplates(): Promise<Template[]>;
  getTemplateBySlug(slug: string): Promise<Template | undefined>;
  
  // Pricing operations
  getPricingPlans(): Promise<PricingPlan[]>;
  
  // Testimonial operations
  getTestimonials(): Promise<Testimonial[]>;
  getFeaturedTestimonials(): Promise<Testimonial[]>;
  
  // FAQ operations
  getFAQItems(): Promise<FaqItem[]>;
}

export class PgStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }
  
  // Newsletter operations
  async subscribeToNewsletter(subscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber> {
    // Check if already exists
    const existing = await db.select()
      .from(newsletterSubscribers)
      .where(eq(newsletterSubscribers.email, subscriber.email));
    
    if (existing.length > 0) {
      // If unsubscribed before, resubscribe them
      if (!existing[0].subscribed) {
        const updated = await db.update(newsletterSubscribers)
          .set({ subscribed: true })
          .where(eq(newsletterSubscribers.email, subscriber.email))
          .returning();
        return updated[0];
      }
      return existing[0];
    }
    
    // New subscriber
    const result = await db.insert(newsletterSubscribers)
      .values(subscriber)
      .returning();
    return result[0];
  }
  
  async unsubscribeFromNewsletter(email: string): Promise<boolean> {
    const result = await db.update(newsletterSubscribers)
      .set({ subscribed: false })
      .where(eq(newsletterSubscribers.email, email))
      .returning();
    return result.length > 0;
  }
  
  // Contact form operations
  async submitContactForm(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const result = await db.insert(contactSubmissions)
      .values(submission)
      .returning();
    return result[0];
  }
  
  // Template operations
  async getTemplates(): Promise<Template[]> {
    return await db.select().from(templates);
  }
  
  async getTemplateBySlug(slug: string): Promise<Template | undefined> {
    const result = await db.select().from(templates).where(eq(templates.slug, slug));
    return result[0];
  }
  
  // Pricing operations
  async getPricingPlans(): Promise<PricingPlan[]> {
    return await db.select().from(pricingPlans);
  }
  
  // Testimonial operations
  async getTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials);
  }
  
  async getFeaturedTestimonials(): Promise<Testimonial[]> {
    return await db.select()
      .from(testimonials)
      .where(eq(testimonials.featured, true))
      .orderBy(desc(testimonials.rating));
  }
  
  // FAQ operations
  async getFAQItems(): Promise<FaqItem[]> {
    return await db.select()
      .from(faqItems)
      .orderBy(faqItems.displayOrder);
  }
}

// Export a singleton instance of PgStorage for use throughout the application
export const storage = new PgStorage();
