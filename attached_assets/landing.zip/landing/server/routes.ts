import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZodError } from "zod";
import {
  insertNewsletterSubscriberSchema,
  insertContactSubmissionSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoints for all our database operations
  
  // Newsletter subscription
  app.post("/api/subscribe", async (req: Request, res: Response) => {
    try {
      const validatedData = insertNewsletterSubscriberSchema.parse(req.body);
      const subscriber = await storage.subscribeToNewsletter(validatedData);
      res.status(200).json({
        success: true,
        message: "Successfully subscribed to newsletter",
        data: subscriber
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          success: false,
          message: "Invalid subscription data",
          errors: error.errors
        });
      } else {
        console.error("Newsletter subscription error:", error);
        res.status(500).json({
          success: false,
          message: "Failed to subscribe to newsletter"
        });
      }
    }
  });

  // Unsubscribe from newsletter
  app.post("/api/unsubscribe", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({
          success: false,
          message: "Email is required"
        });
      }
      
      const success = await storage.unsubscribeFromNewsletter(email);
      if (success) {
        res.status(200).json({
          success: true,
          message: "Successfully unsubscribed from newsletter"
        });
      } else {
        res.status(404).json({
          success: false,
          message: "Email not found in subscription list"
        });
      }
    } catch (error) {
      console.error("Newsletter unsubscribe error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to unsubscribe from newsletter"
      });
    }
  });

  // Contact form submission
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      const validatedData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.submitContactForm(validatedData);
      res.status(200).json({
        success: true,
        message: "Contact form submitted successfully",
        data: submission
      });
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          success: false,
          message: "Invalid contact form data",
          errors: error.errors
        });
      } else {
        console.error("Contact form submission error:", error);
        res.status(500).json({
          success: false,
          message: "Failed to submit contact form"
        });
      }
    }
  });

  // Get templates
  app.get("/api/templates", async (req: Request, res: Response) => {
    try {
      const templates = await storage.getTemplates();
      res.status(200).json({
        success: true,
        data: templates
      });
    } catch (error) {
      console.error("Get templates error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch templates"
      });
    }
  });

  // Get template by slug
  app.get("/api/templates/:slug", async (req: Request, res: Response) => {
    try {
      const { slug } = req.params;
      const template = await storage.getTemplateBySlug(slug);
      
      if (!template) {
        return res.status(404).json({
          success: false,
          message: "Template not found"
        });
      }
      
      res.status(200).json({
        success: true,
        data: template
      });
    } catch (error) {
      console.error("Get template error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch template"
      });
    }
  });

  // Get pricing plans
  app.get("/api/pricing", async (req: Request, res: Response) => {
    try {
      const plans = await storage.getPricingPlans();
      res.status(200).json({
        success: true,
        data: plans
      });
    } catch (error) {
      console.error("Get pricing plans error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch pricing plans"
      });
    }
  });

  // Get testimonials
  app.get("/api/testimonials", async (req: Request, res: Response) => {
    try {
      const featured = req.query.featured === "true";
      const testimonials = featured 
        ? await storage.getFeaturedTestimonials()
        : await storage.getTestimonials();
        
      res.status(200).json({
        success: true,
        data: testimonials
      });
    } catch (error) {
      console.error("Get testimonials error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch testimonials"
      });
    }
  });

  // Get FAQ items
  app.get("/api/faq", async (req: Request, res: Response) => {
    try {
      const faqItems = await storage.getFAQItems();
      res.status(200).json({
        success: true,
        data: faqItems
      });
    } catch (error) {
      console.error("Get FAQ items error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch FAQ items"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
